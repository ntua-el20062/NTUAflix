from flask import request, jsonify, make_response, session
from functools import wraps
from flask_restful import Resource
import json, jwt, datetime
from API import db
import csv
import pymysql


#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ functions @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
def edit_file(table, tsv_data, data_types):
    try:    # Parse the TSV data
        rows = csv.reader(tsv_data.splitlines(), delimiter='\t')
        headers = next(rows)
            
        data = []
        for row in rows:
            entry = {}
            for header, value in zip(headers, row):
                if value == r'\N' or not value:
                    entry[header] = None
                else:
                    try:
                        data_type = data_types.get(header, str)
                        if data_type == int:
                            entry[header] = int(value)
                        elif data_type == float:
                            entry[header] = float(value)
                        else:
                            entry[header] = value.strip()
                    except ValueError as e:
                        # Log the error and skip this row or handle it as needed
                        print(f"Error converting value '{value}' in column '{header}': {e}")
                        continue  # Skip this row
            data.append(entry)

        if not data:
            return {"status": "No data to insert"}, 204

        # Insert data into database
        keys = data[0].keys()
        columns = ', '.join(keys)
        placeholders = ', '.join(['%s'] * len(keys))
        query = f"INSERT INTO {table} ({columns}) VALUES ({placeholders})"
        values = [tuple(row[key] for key in keys) for row in data]

        cur = db.get_db().cursor()
        cur.executemany(query, values)
        db.get_db().commit()
        cur.close()

        return {"status": f"{table} data added"}, 200

    except pymysql.MySQLError as e:
            # Handle MySQL errors
            return {"this error": str(e)}, 500
    except Exception as e:
            # Handle any other exceptions
            return {"that error": str(e)}, 500

def clear_database():
    try:
        cur = db.get_db().cursor
        # List of tables to clear
        tables = ['table1', 'table2', 'table3']
        for table in tables:
            cursor.execute(f"DELETE FROM {table}")
        db.get_db().commit()
        cur.close()
    except pymysql.MySQLError as e:
            # Handle MySQL errors
            return {"this error": str(e)}, 500
    except Exception as e:
            # Handle any other exceptions
            return {"that error": str(e)}, 500


def execute_sql_file(sql_file_path):
    try:
        cur = db.get_db().cursor()
        with open(sql_file_path, 'r') as file:
            sql_script = file.read()
        cur.execute(sql_script)
        db.get_db().commit()
        cur.close()
        return {"status": "Database repopulated succesfully"}, 200

    except pymysql.MySQLError as e:
            # Handle MySQL errors
            return {"this error": str(e)}, 500
    except Exception as e:
            # Handle any other exceptions
            return {"that error": str(e)}, 500

def reset_and_repopulate_database(sql_file_path):
    clear_database()  # Clear existing data
    execute_sql_file(sql_file_path)  # Execute SQL file to repopulate

#@@@@@@@@@@@@@@@ Classes @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@


########################## Διαχειριστικές Απαιτήσεις ##################################
#######################################################################################
class health_check(Resource):
    def get(self):
        # Example database check (modify as per your setup)
        try:
            cur = db.get_db().cursor()
            cur.execute("SELECT 1")
            cur.close()
            db_status = "Connected"
        except Exception as e:
            db_status = f"Error: {e}"

        return {"status": "OK", "database": db_status}, 200

#κάτι τέτοιο πρέπει να κάνετε για όλα τα insertions
class title_basics(Resource):
    def post(self):
        # Define the data types for each column
        title_basics_types = {
            "tconst": str,
            "titleType": str,
            "primaryTitle": str,
            "originalTitle": str,
            "isAdult": int,
            "startYear": int,
            "endYear": int,
            "runtimeMinutes": int,
            "genres": str,
            "img_url": str
        }

        file = request.files.get("tsv_title_basics")
        tsv_title_basics = file.read().decode('utf-8')        
        print(tsv_title_basics)

        # Check if tsv_data is provided
        if not tsv_title_basics:
          return {"error": "No tsv_data provided"}, 400

        return(edit_file("titlebasics", tsv_title_basics, title_basics_types))

class title_akas(Resource):
    def post(self):
    # Define the data types for each column
        aka_types = {
            "titleId": str,
            "ordering": int,
            "title": str,
            "region": str,
            "language": str,
            "type": str,
            "attributes": str,
            "isOriginalTitle": int
        }

        file = request.files.get("tsv_aka")
        tsv_aka = file.read().decode('utf-8')        
        print(tsv_aka)

        # Check if tsv_data is provided
        if not tsv_aka:
            return {"error": "No tsv_data provided"}, 400
        return(edit_file("akas", tsv_aka, aka_types))


class name_basics(Resource):
    def post(self):
    # Define the data types for each column
        professionals_types = {
            "nconst": str,
            "primaryName": int,
            "birthYear": int,
            "deathYear": int,
            "primaryProfession": str,
            "knownForTitles": str,
            "img_url_asset": str
            }

        file = request.files.get("tsv_name_basics")
        tsv_name_basics= file.read().decode('utf-8')        
        print(tsv_name_basics)
        # Check if tsv_data is provided
        if not tsv_name_basics:
            return {"error": "No tsv_data provided"}, 400
        return(edit_file("namebasics", tsv_name_basics, professionals_types))
        

class title_crew(Resource):
    def post(self):
    # Define the data types for each column
        title_crew_types = {
            "tconst": str,
            "directors": str,
            "writers": str
            }

        file = request.files.get("tsv_title_crew")
        tsv_title_crew= file.read().decode('utf-8')        

        # Check if tsv_data is provided
        if not tsv_title_crew:
            return {"error": "No tsv_data provided"}, 400

        return(edit_file("crew", tsv_title_crew, title_crew_types))
        
class title_episode(Resource):
    def post(self):
    # Define the data types for each column
        title_episode_types = {
            "tconst": str,
            "parentTconst": str,
            "seasonNumber": int,
            "episodeNumber": int
            }

        file = request.files.get("tsv_title_episode")
        tsv_title_episode= file.read().decode('utf-8')        

        # Check if tsv_data is provided
        if not tsv_title_episode:
            return {"error": "No tsv_data provided"}, 400

        return(edit_file("episode", tsv_title_episode, title_episode_types))

class title_principal(Resource):
    def post(self):
        title_principal_types = {
            "tconst": str,
            "ordering": int,
            "nconst": str,
            "category": str,
            "job": str,
            "characters": str,
            "img_url_asset": str
            }
         
        file = request.files.get("tsv_title_principal")
        tsv_title_principal= file.read().decode('utf-8')        

        # Check if tsv_data is provided
        if not tsv_title_principal:
            return {"error": "No tsv_data provided"}, 400

        return(edit_file("principals", tsv_title_principal, title_principal_types))

class title_ratings(Resource):
        def post(self):
            title_ratings_types = {
                "tconst": str,
                "averageRating": float,
                "numVotes": int
                }
            
            file = request.files.get("tsv_title_ratings")
            tsv_title_ratings= file.read().decode('utf-8')        

            # Check if tsv_data is provided
            if not tsv_title_ratings:
                return {"error": "No tsv_data provided"}, 400

            return(edit_file("ratings", tsv_title_ratings, title_ratings_types))


class reset_all(Resource):
    def post(self):
        sql_file_path = 'path/to/your/sql_file.sql'  # Path to your SQL file
        try:
            reset_and_repopulate_database(sql_file_path)
            return {"message": "All data reset and repopulated"}, 200
        except Exception as e:
            return {"error": str(e)}, 500


########################### Λειτουργικές Απαιτήσεις ##################################
#######################################################################################

def create_title_object(titleID):
    #Εδώ υλοποιούμε τον δημιουργία του title object
    #όπως ζητείται από την εκφώνηση
    #Προφανώς δεν επιστρέφουμε απλά το titleID
    return None

def create_name_object(nameID):
    #Εδώ υλοποιούμε τον δημιουργία του name object
    #όπως ζητείται από την εκφώνηση
    #Προφανώς δεν επιστρέφουμε απλά το titleID
    return None

class get_title(Resource):
    def get(self, titleID):
        response = create_title_object(titleID)
        return response, 200

class search_title(Resource):
    def get(self):
        return None

class by_genre(Resource):
    def get(self):
        return None

class get_name(Resource):
    def get(self, nameID):
        return nameID

class search_name(Resource):
    def get(self):
        return None

